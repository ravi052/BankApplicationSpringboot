package com.fis.bankapplication.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.fis.bankapplication.model.Customer;
import com.fis.bankapplication.model.Transaction;

@Repository
public class TransactionDaoImpl implements TransactionDao {

	@PersistenceContext
	EntityManager em;

	@Override
	public String createTransaction(Transaction transaction) {
		// TODO Auto-generated method stub
		em.persist(transaction);
		return "Transaction created successful !!!";
	}

	@Override
	public String updateTransaction(Transaction transaction) {
		// TODO Auto-generated method stub
		em.merge(transaction);
		return "Transaction updated successful !!!";
	}

	@Override
	public String deleteTransaction(int tranId) {
		// TODO Auto-generated method stub
		em.remove(getTransaction(tranId));
		return "Transaction deleted successful !!!";
	}

	@Override
	public Transaction getTransaction(int tranId) {
		// TODO Auto-generated method stub
		return em.find(Transaction.class, tranId);
	}

	@Override
	public List<Transaction> getAllTransaction() {
		// TODO Auto-generated method stub
		TypedQuery<Transaction> q = em.createQuery("select t from Transaction t", Transaction.class);

		return q.getResultList();
	}

	@Override
	public List<Transaction> getAllTransactionByAccNumber(long accNumber) {
		// TODO Auto-generated method stub
		TypedQuery<Transaction> q = em.createQuery("select t from Transaction t where t.tranFromAccount=?1",
				Transaction.class);
		q.setParameter(1, accNumber);

		return q.getResultList();

	}

}
