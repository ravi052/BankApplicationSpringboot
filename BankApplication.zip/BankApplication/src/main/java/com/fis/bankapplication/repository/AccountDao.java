package com.fis.bankapplication.repository;

import java.util.List;

import com.fis.bankapplication.exceptions.AccountNotFoundException;
import com.fis.bankapplication.exceptions.NotEnoughBalanceException;
import com.fis.bankapplication.model.Account;

public interface AccountDao {

	public abstract String createAccount(Account account);

	public abstract String updateAccount(Account account);

	public abstract String deleteAccount(long accNumber);

	public abstract Account getAccount(long accNumber);

	// Deposit
	public abstract String depositAccount(long accNumber, double amount) throws AccountNotFoundException;

	// Withdraw
	public abstract String withdrawAccount(long accNumber, double amount)
			throws NotEnoughBalanceException, AccountNotFoundException;

	// Fund Transfer
	public abstract String FundTransferAccount(long fromAccNumber, long toAccNumber, double amount)
			throws NotEnoughBalanceException, AccountNotFoundException;

	// All account list
	public abstract List<Account> getAccountList();

}
