package com.fis.bankapplication.repository;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.fis.bankapplication.exceptions.AccountNotFoundException;
import com.fis.bankapplication.exceptions.NotEnoughBalanceException;
import com.fis.bankapplication.model.Account;
import com.fis.bankapplication.model.Transaction;
import com.fis.bankapplication.service.TransactionService;

@Repository
public class AccountDaoImpl implements AccountDao {

	@PersistenceContext
	EntityManager em;

	@Override
	public String createAccount(Account account) {
		// TODO Auto-generated method stub
		em.persist(account);
		return "Account created successful !!!";
	}

	@Override
	public String updateAccount(Account account) {
		// TODO Auto-generated method stub
		em.merge(account);
		return "Account updated successful !!!";
	}

	@Override
	public String deleteAccount(long accNumber) {
		// TODO Auto-generated method stub
		em.remove(getAccount(accNumber));
		return "Account deleted successful !!!";
	}

	@Override
	public Account getAccount(long accNumber) {
		// TODO Auto-generated method stub
		return em.find(Account.class, accNumber);
	}

	@Override
	public List<Account> getAccountList() {
		// TODO Auto-generated method stub
		TypedQuery<Account> q = em.createQuery("select a from Account a", Account.class);
		return q.getResultList();
	}

	// Deposit Money
	@Override
	public String depositAccount(long accNumber, double amount) throws AccountNotFoundException {
		// TODO Auto-generated method stub

		Account acc = em.find(Account.class, accNumber);
		if (acc == null) {
			throw new AccountNotFoundException("Account number is wrong");
		} else {
			acc.setAccBalance(amount + acc.getAccBalance());
			return "Deposit successful !!!";
		}

	}

	// Withdraw Money
	@Override
	public String withdrawAccount(long accNumber, double amount)
			throws NotEnoughBalanceException, AccountNotFoundException {
		// TODO Auto-generated method stub

		Account acc = em.find(Account.class, accNumber);
		if (acc == null) {
			throw new AccountNotFoundException("Account number is wrong !!!");
		} else {
			double currBalance = acc.getAccBalance();
			if (currBalance < amount) {
				throw new NotEnoughBalanceException("Balance is not sufficient !!!");
			} else {
				acc.setAccBalance(currBalance - amount);
				return "withdraw successful !!!";
			}
		}

	}

	// Fund Transfer
	@Override
	public String FundTransferAccount(long fromAccNumber, long toAccNumber, double amount)
			throws NotEnoughBalanceException, AccountNotFoundException {
		// TODO Auto-generated method stub
		Account acc1 = em.find(Account.class, fromAccNumber);
		Account acc2 = em.find(Account.class, toAccNumber);
		if (acc1 == null) {
			throw new AccountNotFoundException("Personal Account number is wrong !!!");
		} else if (acc2 == null) {
			throw new AccountNotFoundException("Source Account number is wrong !!!");
		} else {
			double currBalance = acc1.getAccBalance();
			if (currBalance < amount) {
				throw new NotEnoughBalanceException("Balance is not sufficient in your personal Account !!!");
			} else {
				acc1.setAccBalance(currBalance - amount);
				acc2.setAccBalance(acc2.getAccBalance() + amount);
				return "Fund transfer successful !!!";
			}
		}

	}

}
