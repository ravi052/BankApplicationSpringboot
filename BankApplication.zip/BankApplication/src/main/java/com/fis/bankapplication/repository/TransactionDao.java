package com.fis.bankapplication.repository;

import java.util.List;

import com.fis.bankapplication.model.Account;
import com.fis.bankapplication.model.Transaction;

public interface TransactionDao {

	// Create transaction
	public abstract String createTransaction(Transaction transaction);

	// Update transaction
	public abstract String updateTransaction(Transaction transaction);

	// Delete transaction
	public abstract String deleteTransaction(int tranId);

	// Get transaction ById
	public abstract Transaction getTransaction(int tranId);

	// Transaction list by AccNumber
	public abstract List<Transaction> getAllTransactionByAccNumber(long accNumber);

	// All transaction list
	public abstract List<Transaction> getAllTransaction();

}
